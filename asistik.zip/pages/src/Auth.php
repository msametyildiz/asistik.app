<?php

namespace Samet\Asistik;

class Auth
{
    public function login($username, $password)
    {
        // Burada giriş işlemini gerçekleştirebilirsiniz
        return "Kullanıcı adı: $username, Şifre: $password ile giriş yapıldı.";
    }
}
