<nav class="navbar">
  <button id="toggle-btn" class="toggle-btn" >
    <img src="assets/images/menu.png" alt="Menu" style="width: 24px; height: 24px;background-color:white !important;">
  </button>
</nav>