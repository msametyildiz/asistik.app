
<footer class="site-footer">
    <div class="footer-content">
      <p>Copyright © 2024 <strong> Company of MSY</strong>. All rights reserved.</p>
    </div>
  </footer>